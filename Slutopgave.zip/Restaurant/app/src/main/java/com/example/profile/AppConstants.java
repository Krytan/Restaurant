package com.example.profile;

public class AppConstants {
    public static final int RESULT_CODE_SECOND = 2000;
    public static final int RESULT_CODE_THIRD = 3000;
    public static final int RESULT_CODE_CANCELED = -1;
}
